from pylayers.util.pydb import *

#server = 'IETR-A99F50DEDA\SQLEXPRESSDB'
#database = 'NEWWHERE2'
#table = 'ACOLinkMeasurements'
#
#sql = pysql(server= server,dbname=database)
#sql.connect_mssql()
#tables = sql.gettables()
#columns = sql.getcolumns(table)
#strcolumns = ", ".join(columns[1:])
#
#cmd="select * from ACOLinkMeasurements"
#cmd1="insert into ACOLinkMeasurements("+strcolumns+") values (387,385,30,getdate())"
#cmd2="delete from ACOLinkMeasurements where ACOLinkMeasurementID=26025"
#print cmd
#print cmd1
#print cmd2
#result = sql.runselectcmd(cmd)
##sql.runinsertcmd(cmd1)
##sql.rundeletecmd(cmd2)
