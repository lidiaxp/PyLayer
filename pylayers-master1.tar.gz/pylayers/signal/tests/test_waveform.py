from pylayers.signal.waveform import *
w = Waveform(type='W1offset')



