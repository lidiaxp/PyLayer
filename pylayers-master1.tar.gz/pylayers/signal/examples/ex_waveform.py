from pylayers.signal.waveform import *
param= {'type' : 'generic',\
            'band': 0.499,\
            'fc': 4.493,\
            'fe': 100,\
            'thresh': 3,\
            'tw': 30}
#w = Waveform({'type':'W1offset'})
w = Waveform()
w.show()
plt.show()


