from pylayers.antprop.antenna import *

A = Antenna(typ='azel',param={'filename':'antenna.ant','pol':'V'})

