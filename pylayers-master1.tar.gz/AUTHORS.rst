+ Bernard Uguen 
  bernard.uguen@univ-rennes1.fr
+ Nicolas Amiot  
  nicolas.amiot@univ-rennes1.fr
+ Mohamed Laaraiedh 
  mohamedh.laaraiedh@univ-rennes1.fr
+ Meriem Mhedhbi  
  meriem.mhedhbi@univ-rennes1.fr
+ Stephane Avrillon 
+ Roxana Burghelea	
+ Eric Plouhinec
+ Friedman Tchoffo Talom 
+ Taguhi Chaluyman
+ Yu Lei
